﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RaffleWebRole
{
    public class NotificationHub : Hub
    {
        public NotificationHub()
        {
            _instance = this;
        }

        private static NotificationHub _instance { get; set; }

        public static void BroadcastNewRaffle(Guid raffleId)
        {
            if (_instance != null)
            {
                _instance.Clients.All.broadcastNewRaffle(raffleId);
            }
        }

        public static void BroadcastNewBetForRaffle(Guid raffleId, int ticketNumber, string betDescription)
        {
            if (_instance != null)
            {
                _instance.Clients.All.broadcastNewBetForRaffle(raffleId, ticketNumber, betDescription);
            }
        }

        public static void Reload(Guid raffleId)
        {
            if (_instance != null)
            {
                _instance.Clients.All.reload(raffleId);
            }
        }

        public static void BroadcastResultMessage(string sessionId, Guid raffleId, string resultMessage)
        {
            if (_instance != null)
            {
                _instance.Clients.All.broadcastResultMessage(sessionId, raffleId, resultMessage);
            }
        }
    }
}