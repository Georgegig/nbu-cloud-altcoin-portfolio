﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RaffleCommon;
using Microsoft.AspNet.SignalR;
using System.Web.Services;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace RaffleWebRole
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            initializeScriptManager();
            initializeRaffleManager();

            if (!IsPostBack)
            {
                readQueryString();
                updatePageControls();
            }
        }

        private RaffleManager _raffleManager;
        private System.Timers.Timer _updateTimer;

        private void initializeScriptManager()
        {
            scriptManager.RegisterAsyncPostBackControl(btnCreateNewRaffle);
            scriptManager.RegisterAsyncPostBackControl(btnPlaceBet);
            scriptManager.RegisterAsyncPostBackControl(btnCloseRaffle);
        }

        private void initializeRaffleManager()
        {
            IDataAccess dataAccess = null;
            if (ConfigurationManager.AppSettings["RaffleStorageMode"] == Constants.RaffleStorageModes.SQLServer)
            {
                dataAccess = new SqlServerDataAccess();

            }
            else if (ConfigurationManager.AppSettings["RaffleStorageMode"] == Constants.RaffleStorageModes.Table)
            {
                dataAccess = new CloudTableDataAccess();
            }

            CloudQueueAccess queueAccess = new CloudQueueAccess();
            CloudBlobAccess blobAccess = new CloudBlobAccess();

            _raffleManager = new RaffleManager(dataAccess, queueAccess, blobAccess);
        }

        private void readQueryString()
        {
            string queryStringRaffleId = Request.QueryString["raffleId"];

            if (!string.IsNullOrEmpty(queryStringRaffleId))
            {
                Guid selectedRaffleId = Guid.Parse(queryStringRaffleId);
                CurrentRaffleId = selectedRaffleId;

                string queryStringTicketNumber = Request.QueryString["ticketNumber"];
                if (!string.IsNullOrEmpty(queryStringTicketNumber))
                {
                    int ticketNumber = int.Parse(queryStringTicketNumber);
                    downloadTicket(selectedRaffleId, ticketNumber);
                }
            }
            else
            {
                CurrentRaffleId = null;
            }
        }

        private void updatePageControls()
        {
            if (CurrentRaffleId.HasValue)
            {
                divCurrentRaffleSelected.Visible = true;
                divSelectRaffle.Visible = false;

                updateCurrentRaffle();
            }
            else
            {
                divCurrentRaffleSelected.Visible = false;
                divSelectRaffle.Visible = true;

                loadExistingRaffles();
            }
        }

        private void updateCurrentRaffle()
        {
            RaffleEntity raffle = _raffleManager.ReadRaffle(CurrentRaffleId.Value);
            CurrentRaffleStatus = raffle.GetStatus();

            switch (CurrentRaffleStatus)
            {
                case RaffleStatus.Open:
                    divEditCurrentRaffle.Visible = true;
                    divResult.Visible = false;
                    break;
                case RaffleStatus.Closed:
                case RaffleStatus.Processed:
                    divEditCurrentRaffle.Visible = false;
                    divResult.Visible = true;
                    startUpdateTimer();
                    break;
                default:
                    throw new ArgumentOutOfRangeException("CurrentRaffleStatus out of range.");
            }

            loadBetsForRaffle();
        }

        private void loadExistingRaffles()
        {
            List<RaffleEntity> raffles = _raffleManager.ReadAllRaffles();
            IEnumerable<Guid> raffleIds = raffles.Select(raffle => raffle.Id);

            ulRaffles.Controls.Clear();
            foreach (Guid raffleId in raffleIds)
            {
                var raffleListItem = new HtmlGenericControl();

                raffleListItem.InnerHtml = string.Format(
                    "<li id=\"{0}\" title=\"Click to select raffle\"><a href=\"/Default.aspx?raffleId={0}\">{0}</a></li>",
                    raffleId);

                ulRaffles.Controls.Add(raffleListItem);
            }
        }

        private void loadBetsForRaffle()
        {
            List<BetEntity> betsForRaffle = _raffleManager.ReadBets(CurrentRaffleId.Value);

            ulBets.Controls.Clear();
            foreach (BetEntity bet in betsForRaffle)
            {
                string betDescription = createBetDescription(bet);
                var betId = bet.RaffleId.ToString() + bet.TicketNumber.ToString();

                var betListItem = new HtmlGenericControl();
                betListItem.InnerHtml = string.Format(
                    "<li id=\"{0}\" title=\"Click to download ticket\"><a href=\"/Default.aspx?raffleId={1}&ticketNumber={2}\">{3}</a></li>",
                    betId,
                    bet.RaffleId,
                    bet.TicketNumber,
                    betDescription);

                ulBets.Controls.Add(betListItem);
            }
        }

        protected RaffleStatus CurrentRaffleStatus { get; private set; }

        protected Guid? CurrentRaffleId
        {
            get
            {
                object objectCurrentRaffleId = ViewState[CurrentRaffleIdKey];

                if (objectCurrentRaffleId == null)
                {
                    return null;
                }

                Guid currentRaffleId = (Guid)objectCurrentRaffleId;

                return currentRaffleId;
            }
            set
            {
                ViewState[CurrentRaffleIdKey] = value;
            }
        }

        private const string CurrentRaffleIdKey = "CurrentRaffleId";

        protected void btnCreateNewRaffle_OnClick(object sender, EventArgs e)
        {
            RaffleEntity newRaffle = _raffleManager.CreateNewRaffle();
            NotificationHub.BroadcastNewRaffle(newRaffle.Id);
        }

        protected void btnPlaceBet_OnClick(object sender, EventArgs e)
        {
            try
            {
                int betNumber = int.Parse(tbBetNumber.Text);
                tbBetNumber.Text = string.Empty;

                BetEntity bet = _raffleManager.PlaceBet(CurrentRaffleId.Value, betNumber, Session.SessionID);
                string betDescription = createBetDescription(bet);

                NotificationHub.BroadcastNewBetForRaffle(CurrentRaffleId.Value, bet.TicketNumber, betDescription);

            }
            catch (Exception ex)
            {
                Message = ex.Message;
            }
        }

        private string createBetDescription(BetEntity bet)
        {
            string betDescription = string.Format("Ticket #: {0} Bet: {1} Submited By: {2}",
                                             bet.TicketNumber,
                                             bet.BetNumber,
                                             bet.SubmittedBy);

            return betDescription;
        }

        protected string Message { get; private set; }

        private void downloadTicket(Guid raffleId, int ticketNumber)
        {
            byte[] fileContents = null;
            try
            {
                fileContents = _raffleManager.GetTicketFileContents(raffleId, ticketNumber);
            }
            catch (InvalidOperationException invalidOperationException)
            {
                Message = invalidOperationException.Message;
                return;
            }

            if (fileContents == null)
            {
                return;
            }

            // Send the file contents as a download to the client browser
            string downloadFileName = string.Format("RaffleId_{0}_TicketNumber_{1}.txt", CurrentRaffleId.Value, ticketNumber);
            Response.ContentType = @"application/x-msdownload";
            Response.AppendHeader("content-disposition", "attachment; filename=" + downloadFileName);

            Response.BinaryWrite(fileContents);
            Response.Flush();
            Response.End();
        }

        protected void btnCloseRaffle_OnClick(object sender, EventArgs e)
        {
            try
            {
                _raffleManager.CloseRaffleAndDraw(CurrentRaffleId.Value);
                NotificationHub.Reload(CurrentRaffleId.Value);
            }
            catch (InvalidOperationException invalidOperationException)
            {
                Message = invalidOperationException.Message;
            }
        }

        protected void btnSelectAnotherRaffle_OnClick(object sender, EventArgs e)
        {
            stopUpdateTimer();
            Response.Redirect(Request.Url.AbsolutePath);
        }

        private void startUpdateTimer()
        {
            if (_updateTimer == null)
            {
                _updateTimer = new System.Timers.Timer(3000);
                _updateTimer.Elapsed += _updateTimer_Elapsed;
            }

            _updateTimer.Start();
        }

        private void stopUpdateTimer()
        {
            if (_updateTimer != null)
            {
                _updateTimer.Stop();
                _updateTimer = null;
            }
        }

        private void _updateTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            updateRaffleResult();
        }

        private void updateRaffleResult()
        {
            RaffleEntity raffle = _raffleManager.ReadRaffle(CurrentRaffleId.Value);

            string resultMessage = "Result not available yet.";

            if (raffle.GetStatus() == RaffleStatus.Processed)
            {
                resultMessage = string.Format(
                    "Winning number: {0}; Winning ticket numbers: {1}",
                    raffle.WinningNumber,
                    raffle.WinningTicketsResult);

                stopUpdateTimer();
            }

            NotificationHub.BroadcastResultMessage(Session.SessionID, CurrentRaffleId.Value, resultMessage);
        }
    }
}