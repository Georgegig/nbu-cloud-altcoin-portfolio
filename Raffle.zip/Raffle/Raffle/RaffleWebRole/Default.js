﻿$(function () {

    jQuery.fn.flash = function () {
        var current = this.css('backgroundColor');
        this.animate({ backgroundColor: 'rgb(255,216,0)' }, 250)
            .animate({ backgroundColor: current }, 250);
    };

    var notificationHub = $.connection.notificationHub;
    notificationHub.client.broadcastResultMessage = function (sessionId, raffleId, resultMessage) {
        var currentSessionId = $('#labelCurrentSessionId').text();
        if (currentSessionId != sessionId) {
            return;
        }
        var currentRaffleId = $('#labelCurrentRaffleId').text();
        if (currentRaffleId != raffleId) {
            return;
        }
        if ($('#labelResult').text() != resultMessage) {
            $('#labelResult').text(resultMessage);
            $('#labelResult').flash();
        }
    };

    notificationHub.client.broadcastNewRaffle = function (raffleId) {
        $('#ulRaffles').append('<li id="' + raffleId + '" title="Click to select raffle"><a href="/Default.aspx?raffleId=' + raffleId + '">' + raffleId + '</a></li>');
        $('#' + raffleId).flash();
    };

    notificationHub.client.broadcastNewBetForRaffle = function (raffleId, ticketNumber, betDescription) {
        var currentRaffleId = $('#labelCurrentRaffleId').text();
        if (currentRaffleId != raffleId) {
            return;
        }
        var betId = raffleId.toString() + ticketNumber.toString();
        $('#ulBets').append('<li id="' + betId + '" title="Click to download ticket"><a href="/Default.aspx?raffleId=' + raffleId + '&ticketNumber=' + ticketNumber + '">' + betDescription + '</a></li>');
        $('#' + betId).flash();
    };

    notificationHub.client.reload = function (raffleId) {
        var currentRaffleId = $('#labelCurrentRaffleId').text();
        if (currentRaffleId != raffleId) {
            return;
        }
        location.reload();
    };

    $.connection.hub.start();
});