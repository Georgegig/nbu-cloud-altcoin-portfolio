using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using RaffleCommon;

namespace RaffleWebRole
{
    public class WebRole : RoleEntryPoint
    {
        public override bool OnStart()
        {
            var cloudBlobAccess = new CloudBlobAccess();
            cloudBlobAccess.ClearBlobs();

            return base.OnStart();
        }
    }
}