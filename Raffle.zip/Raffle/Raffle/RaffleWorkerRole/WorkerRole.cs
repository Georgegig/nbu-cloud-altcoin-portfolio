using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using Microsoft.WindowsAzure.Storage.Table;
using RaffleCommon;
using System.Configuration;

namespace RaffleWorkerRole
{
    public class WorkerRole : RoleEntryPoint
    {
        private CloudQueueAccess _cloudQueueAccess;
        private IDataAccess _dataAccess;

        public override void Run()
        {
            Trace.WriteLine("RaffleWorkerRole entry point called", "Information");

            while (true)
            {
                Thread.Sleep(15000);

                CloudQueueMessage drawRaffleMessage = _cloudQueueAccess.ReadDrawRaffleMessage();

                if (drawRaffleMessage != null)
                {
                    Guid raffleId;

                    try
                    {
                        raffleId = Guid.Parse(drawRaffleMessage.AsString);
                        Trace.WriteLine("Processing Raffle id: " + raffleId.ToString());
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine("Cannot parse Id from message." + ex.Message);
                        _cloudQueueAccess.DeleteDrawRaffleMessage(drawRaffleMessage);

                        return;
                    }

                    try
                    {
                        RaffleEntity raffle = _dataAccess.ReadRaffle(raffleId);

                        if (raffle == null)
                        {
                            Trace.WriteLine("Raffle not found. Raffle ID: " + raffleId);

                            _cloudQueueAccess.DeleteDrawRaffleMessage(drawRaffleMessage);
                            continue;
                        }

                        if (raffle.GetStatus() == RaffleStatus.Processed)
                        {
                            Trace.WriteLine("Raffle is already precessed. Raffle ID: " + raffleId);

                            _cloudQueueAccess.DeleteDrawRaffleMessage(drawRaffleMessage);
                            continue;
                        }

                        var random = new Random();
                        raffle.WinningNumber = random.Next(1, 6);

                        List<BetEntity> betsForRaffle = _dataAccess.ReadBetsForRaffle(raffleId);
                        List<int> winningTicketNumbers = new List<int>();

                        foreach (var bet in betsForRaffle)
                        {
                            if (bet.BetNumber == raffle.WinningNumber)
                            {
                                winningTicketNumbers.Add(bet.TicketNumber);
                            }
                        }

                        raffle.SetStatus(RaffleStatus.Processed);
                        raffle.UpdateDate = DateTime.Now;

                        if (winningTicketNumbers.Count > 0)
                        {
                            raffle.WinningTicketsResult = string.Join(", ", winningTicketNumbers);
                        }
                        else
                        {
                            raffle.WinningTicketsResult = "No winning tickets.";
                        }

                        _dataAccess.UpdateRaffle(raffle);

                        Trace.WriteLine("Raffle processed. Raffle ID: " + raffleId);
                        Trace.WriteLine("Winning number: " + raffle.WinningNumber);

                        _cloudQueueAccess.DeleteDrawRaffleMessage(drawRaffleMessage);
                    }
                    catch (Exception ex)
                    {
                        Trace.WriteLine("Error processing raffle." + ex.Message);
                    }
                }
            }
        }

        public override bool OnStart()
        {
            // Set the maximum number of concurrent connections 
            ServicePointManager.DefaultConnectionLimit = 12;

            Trace.AutoFlush = true;

            //if (ConfigurationManager.AppSettings["RaffleStorageMode"] == Constants.RaffleStorageModes.SQLServer)
            //{
                _dataAccess = new SqlServerDataAccess();

            //}
            //else if (ConfigurationManager.AppSettings["RaffleStorageMode"] == Constants.RaffleStorageModes.Table)
            //{
                //_dataAccess = new CloudTableDataAccess();
            //}

            _cloudQueueAccess = new CloudQueueAccess();

            initializeStorage();

            return base.OnStart();
        }

        private void initializeStorage()
        {
            File.Delete(@"C:\RaffleWorkerRole.log");

            _dataAccess.ClearData();
            _cloudQueueAccess.ClearDrawRaffleQueue();
        }
    }
}