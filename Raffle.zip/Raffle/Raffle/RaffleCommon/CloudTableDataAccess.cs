﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;

namespace RaffleCommon
{
    public class CloudTableDataAccess : IDataAccess
    {
        public RaffleEntity ReadRaffle(Guid raffleId)
        {
            CloudTable tableRaffle = createTableClient(Constants.TableNames.Raffle);

            if (!tableRaffle.Exists())
            {
                throw new ArgumentOutOfRangeException("Raffle not found. Raffle ID: " + raffleId);
            }

            TableQuery<RaffleEntity> query = new TableQuery<RaffleEntity>()
                .Where(TableQuery.GenerateFilterCondition(
                            Constants.ColumnNames.RowKey,
                            QueryComparisons.Equal,
                            raffleId.ToString()));

            IEnumerable<RaffleEntity> raffles = tableRaffle.ExecuteQuery(query);
            RaffleEntity raffle = raffles.FirstOrDefault();
            return raffle;
        }

        public List<RaffleEntity> ReadAllRaffles()
        {
            CloudTable tableRaffle = createTableClient(Constants.TableNames.Raffle);

            if (!tableRaffle.Exists())
            {
                return new List<RaffleEntity>();
            }

            TableQuery<RaffleEntity> query = new TableQuery<RaffleEntity>();
            List<RaffleEntity> raffles = tableRaffle.ExecuteQuery(query).ToList();
            return raffles;
        }

        public void InsertRaffle(RaffleEntity raffle)
        {
            CloudTable tableRaffle = createTableClient(Constants.TableNames.Raffle);

            tableRaffle.CreateIfNotExists();

            TableOperation insertOperation = TableOperation.Insert(raffle);
            tableRaffle.Execute(insertOperation);
        }

        public void UpdateRaffle(RaffleEntity raffle)
        {
            CloudTable tableRaffleResults = createTableClient(Constants.TableNames.Raffle);

            tableRaffleResults.CreateIfNotExists();

            TableOperation insertOperation = TableOperation.Merge(raffle);
            tableRaffleResults.Execute(insertOperation);
        }

        public List<BetEntity> ReadBetsForRaffle(Guid raffleId)
        {
            CloudTable tableBets = createTableClient(Constants.TableNames.Bet);

            if (!tableBets.Exists())
            {
                return new List<BetEntity>();
            }

            TableQuery<BetEntity> query = new TableQuery<BetEntity>()
                .Where(TableQuery.GenerateFilterCondition(
                            Constants.ColumnNames.PartitionKey,
                            QueryComparisons.Equal,
                            raffleId.ToString()));

            List<BetEntity> betsForRaffle = tableBets.ExecuteQuery(query).ToList();
            return betsForRaffle;
        }

        public void InsertBet(BetEntity bet)
        {
            CloudTable tableBets = createTableClient(Constants.TableNames.Bet);
            tableBets.CreateIfNotExists();

            TableOperation insertOperation = TableOperation.Insert(bet);
            tableBets.Execute(insertOperation);
        }

        public void ClearData()
        {
            CloudTable tableBets = createTableClient(Constants.TableNames.Bet);
            tableBets.DeleteIfExists();

            CloudTable tableRaffleResults = createTableClient(Constants.TableNames.Raffle);
            tableRaffleResults.DeleteIfExists();
        }

        private CloudTable createTableClient(string tableName)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.DevelopmentStorageAccount;
            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();
            CloudTable table = tableClient.GetTableReference(tableName);

            return table;
        }
    }
}