﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RaffleCommon
{
    public class Constants
    {
        public class TableNames
        {
            public const string Raffle = "Raffle";
            public const string Bet = "Bet";
        }

        public class ColumnNames
        {
            public const string Id = "Id";
            public const string RaffleId = "RaffleId";
            public const string Status = "Status";
            public const string WinningNumber = "WinningNumber";
            public const string WinningTicketsResult = "WinningTicketsResult";
            public const string RowKey = "RowKey";
            public const string PartitionKey = "PartitionKey";
            public const string TicketNumber = "TicketNumber";
            public const string BetNumber = "BetNumber";
            public const string SubmittedBy = "SubmittedBy";
            public const string CreateDate = "CreateDate";
            public const string UpdateDate = "UpdateDate";
        }

        public class QueueNames
        {
            public const string DrawRaffle = "drawraffle";
        }

        public class BlobNames
        {
            public const string DrawRaffle = "raffle";
        }

        public class RaffleStorageModes
        {
            public const string Table = "Table";
            public const string SQLServer = "SQLServer";
        }
    }
}