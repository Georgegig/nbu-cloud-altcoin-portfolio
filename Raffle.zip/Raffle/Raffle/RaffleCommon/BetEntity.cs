﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage.Table;

namespace RaffleCommon
{
    public class BetEntity : TableEntity
    {
        private Guid _raffleId;
        public Guid RaffleId
        {
            get
            {
                return _raffleId;
            }
            set
            {
                _raffleId = value;
                PartitionKey = _raffleId.ToString();
            }
        }

        private int _ticketNumber;
        public int TicketNumber
        {
            get
            {
                return _ticketNumber;
            }
            set
            {
                _ticketNumber = value;
                RowKey = _ticketNumber.ToString();
            }
        }

        public int BetNumber { get; set; }

        public string SubmittedBy { get; set; }

        public DateTime CreateDate { get; set; }

        public DateTime UpdateDate { get; set; }
    }
}
