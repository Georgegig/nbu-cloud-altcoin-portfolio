﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using Microsoft.WindowsAzure.Storage.Table;

namespace RaffleCommon
{
    public class RaffleEntity : TableEntity
    {
        public RaffleEntity()
        {
            PartitionKey = Constants.TableNames.Raffle;
            WinningNumber = -1;
        }

        private Guid _id;
        public Guid Id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
                RowKey = _id.ToString();
            }
        }

        public int Status { get; set; }

        public void SetStatus(RaffleStatus status)
        {
            Status = (int)status;
        }

        public RaffleStatus GetStatus()
        {
            return (RaffleStatus)Status;
        }

        public int WinningNumber { get; set; }

        public string WinningTicketsResult { get; set; }

        public DateTime CreateDate { get; set; }

        public DateTime UpdateDate { get; set; }
    }
}