﻿using System;
using System.Collections.Generic;

namespace RaffleCommon
{
    public interface IDataAccess
    {
        RaffleEntity ReadRaffle(Guid raffleId);
        List<RaffleEntity> ReadAllRaffles();
        void InsertRaffle(RaffleEntity raffle);
        void UpdateRaffle(RaffleEntity raffle);
        List<BetEntity> ReadBetsForRaffle(Guid raffleId);
        void InsertBet(BetEntity bet);
        void ClearData();
    }
}